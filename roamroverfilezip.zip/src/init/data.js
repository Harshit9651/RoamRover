const Sampledata=[
    {title: 'My villa ',
    descripition: 'this is my sweet home ressidency ',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=600',
    Price:200,
    Location:'near ghakat cop',
    countery:'India'},
  
  
  { 
    
    title: 'Royal resort',
  descripition: "rhotel offers a seamless blend of modern elegance and timeless charm, providing an unforgettable retreat for both leisure and business travelers.",
  image:"https://images.pexels.com/photos/2480608/pexels-photo-2480608.jpeg?auto=compress&cs=tinysrgb&w=600" ,
  Price:120,
  Location:"knnot place goa , under swaat resort place'",
  countery:'India'
},
  
{
    title:"Sunset Haven Resort & Spa",
    descripition: "Immerse yourself in luxury at Sunset Haven, where modern elegance meets natural serenity. Unwind with panoramic views, indulge in world-class spa treatments, and savor culinary delights.",

    image:"https://images.pexels.com/photos/2525899/pexels-photo-2525899.jpeg?auto=compress&cs=tinysrgb&w=600",
    Price: 250 ,
    Location: "Coastal retreat in Malibu, California, USA",
    countery:"USA,",
},
  {title:"Royal Oasis Retreat",
    Description: "Experience regal charm at the Royal Oasis Retreat. Lavish rooms, gourmet dining, and impeccable service await, making every moment a royal affair.",
    image:"https://images.pexels.com/photos/261388/pexels-photo-261388.jpeg?auto=compress&cs=tinysrgb&w=600",

    Price: 350,
    Location: "Historic district of Edinburgh, Scotland",
    countery:"America",
    },
    {
  title:"Azure Skies Boutique Hotel",
  descripition:"Discover sophistication and contemporary design at Azure Skies. Breathtaking views, chic interiors, and personalized service redefine the boutique hotel experience",

  image:"https://images.pexels.com/photos/70441/pexels-photo-70441.jpeg?auto=compress&cs=tinysrgb&w=600",
  Price: 180 ,
  Location: "Overlooking the Mediterranean in Santorini, Greece",
  countery:"Santorito",
},

  
  
{
    title:"Mystic Gardens Resort & Spa",
    descripition: "Surrender to the enchantment of Mystic Gardens. Lush landscapes, tranquil spa retreats, and private villas create an oasis of relaxation and luxury.",
    image:"https://images.pexels.com/photos/678725/pexels-photo-678725.jpeg?auto=compress&cs=tinysrgb&w=600",
    Price: 300,
    Location: "Ubud, Bali, Indonesia",
    countery:"Indonasia",
},
  
  
  {
    title:"Elysian Escape Hotel",
    descripition: "Elysian Escape beckons with its blend of modern luxury and timeless charm. Immerse yourself in opulent suites, exquisite dining, and personalized service.",
  image:"https://images.pexels.com/photos/2227774/pexels-photo-2227774.jpeg?auto=compress&cs=tinysrgb&w=600",
  Price: 400,
  Location: "Central Paris,", 
  countery:"France",
  },
  
  {title:"Celestial Sands Beach Resort",
  descripition:" Embrace the coastal allure of Celestial Sands. With private beach access, seaside dining, and sumptuous accommodations, your beachfront escape awaits.",

     image:"https://images.pexels.com/photos/163864/santorini-oia-greece-travel-163864.jpeg?auto=compress&cs=tinysrgb&w=600",
    Price: 280,
    Location: "Cancun, Mexico",
    countery:"Mexico"
    
  },
 {
    title:"Urban Zen Tower",
    descripition:" Find tranquility in the heart of the city at Urban Zen Tower. A sanctuary of modern design, wellness amenities, and panoramic city views await discerning travelers.00",
     image:"https://images.pexels.com/photos/1450363/pexels-photo-1450363.jpeg?auto=compress&cs=tinysrgb&w=600",

    Price:220 ,
    Location: "Midtown Manhattan, New York, USA",
    countery:"USA",
 },
  
  
  {
    title:"Sapphire Lakeside Lodge",
    descripition:" Escape to the serenity of Sapphire Lakeside Lodge. Nestled amidst pristine lakes and mountains, this lodge offers cozy cabins, outdoor adventures, and starlit evenings.0",

  image:"https://images.pexels.com/photos/51212/pexels-photo-51212.jpeg?auto=compress&cs=tinysrgb&w=600",
  Price:180,
  Location:"Queenstown, New Zealand,",

  countery:"New Zeleend,"
  
  },
  
 {
    title:"Golden Mirage Desert Resort",
    descripition: "Embark on a desert oasis adventure at Golden Mirage. Luxurious tents, camel safaris, and starry nights create an unforgettable experience in the heart of the dunes."
    ,
    image:"https://images.pexels.com/photos/1198838/pexels-photo-1198838.jpeg?auto=compress&cs=tinysrgb&w=600",
    
    Price: 320,
    Location: "Sahara Desert, Morocco",
    countery: "Morocco,"

 },
  
  
 {
    title:"Riverside Manor Heritage Hotel",
    descripition: "Step into a bygone era at Riverside Manor. This heritage hotel exudes charm with its antique decor, riverside views, and timeless elegance.",

     image:"https://images.pexels.com/photos/1198838/pexels-photo-1198838.jpeg?auto=compress&cs=tinysrgb&w=600",

    
    Price: 230,
    Location: "Udaipur, Rajasthan", 
    countery:"India"
 }



]
module.exports = Sampledata;
